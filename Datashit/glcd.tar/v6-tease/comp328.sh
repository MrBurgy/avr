#!/bin/sh
clear
avr-gcc -lm -funsigned-char -funsigned-bitfields -Os -fpack-struct -fshort-enums -std=c99 -Wall -fdata-sections -mmcu=atmega328 -o program.elf program.c \
&& \
avr-objcopy  -O ihex program.elf program.hex \
&& \
avrdude -p m328p -c usbasp -e -U flash:w:program.hex
