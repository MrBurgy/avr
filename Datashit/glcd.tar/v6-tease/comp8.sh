#!/bin/sh
clear
avr-gcc -lm -funsigned-char -funsigned-bitfields -Os -fpack-struct -fshort-enums -std=c99 -Wall -fdata-sections -mmcu=atmega8 -o program.elf program.c \
&& \
avr-objcopy  -O ihex program.elf program.hex \
#&& \
#avrdude -p m8 -c usbasp -e -U flash:w:program.hex
