#define black	0x0000
#define blue	0x001F
#define red	0xF800
#define green	0x07E0
#define cyan	0x07FF
#define magenta	0xF81F
#define yellow	0xFFE0  
#define white	0xFFFF
