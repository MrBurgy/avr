#include <avr/io.h>
#include "glcd.c"
#define F_CPU 8000000UL
//#include "ILI9341.c"

int main() {

	glcd_init();
	glcd_led_on();

	/*
	glcd_string("Konacno, jebote.@",0,0,2,blue);
	glcd_float(123.45,0,20,2,yellow);

	while(1)
	{
		int i;
		for(i=0;i<10;i++)
		{
			glcd_number(i,160,200,4,red);
			_delay_ms(500);
			glcd_clr(160,200,4);
			if(i>=9)
				i=0;
		}
	}
	*/
	glcd_rectangle(10,10,100,100,red);

	return 0;
}
