/*
GLCD       AT8 AT32
VCC
GND
CS	PD5 11 19
RST	PD4 6  18
DC	PD6 12 20
MOSI	PB3 17  6
SCK	PB5 19  8
LED	PD7 13 21
MISO	PB4 18  7
*/

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include "colors.h"

#define MIN_X   0
#define MIN_Y   0
#define MAX_X   239
#define MAX_Y   319

#define LEFT2RIGHT	0
#define DOWN2UP		1
#define RIGHT2LEFT	2
#define UP2DOWN		3

//#define BGCOLOR	black
#define BGCOLOR	blue

#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))

void glcd_cs_low() {
	DDRD |= 0b100000;	// PD5 je izlaz
	PORTD &=~ 0b100000;	// PD5 je 0
}
void glcd_cs_high() {
	DDRD |= 0b100000;
	PORTD |=  0b100000;
}
void glcd_dc_low() {
	DDRD |= 0b1000000;	// PD6
	PORTD &=~ 0b1000000;
}
void glcd_dc_high() {
	DDRD |= 0b1000000;
	PORTD |=  0b1000000;
}
void glcd_led_off() {
	DDRD |= 0b10000000;	// PD7
	PORTD &=~ 0b10000000;
}
void glcd_led_on() {
	DDRD |= 0b10000000;
	PORTD |=  0b10000000;
}
void glcd_rst_off() {
	DDRD |= 0b10000;	// PD4
	PORTD |=  0b10000;
}
void glcd_rst_on() {
	DDRD |= 0b10000;
	PORTD &=~ 0b10000;
}

const unsigned char simpleFont[][8];

// prototipi
void glcd_sendCmd(unsigned char data);
void glcd_sendData(unsigned char data);
void glcd_sendData16(unsigned int data);
void glcd_init (void);
void glcd_setCol(unsigned int StartCol,unsigned int EndCol);
void glcd_setPage(unsigned int StartPage,unsigned int EndPage);
void glcd_fillScreen(unsigned int XL, unsigned int XR, unsigned int YU, unsigned int YD,  unsigned int color);
void glcd_fillScreen_void();
void glcd_setXY(unsigned int poX, unsigned int poY);
void glcd_setPixel(unsigned int poX, unsigned int poY, unsigned int color);
void glcd_fillRectangle(unsigned int poX, unsigned int poY, unsigned int length, unsigned int width,  unsigned int color);
void glcd_line( unsigned int x0,unsigned int y0,unsigned int x1, unsigned int y1, unsigned int color);
void glcd_hline( unsigned int poX, unsigned int poY, unsigned int length, unsigned int color);
void glcd_vline( unsigned int poX, unsigned int poY, unsigned int length, unsigned int color);
void glcd_rectangle(unsigned int poX, unsigned int poY, unsigned int length, unsigned int width, unsigned int color);
void glcd_circle(int poX, int poY, int r, unsigned int color);
void glcd_fillCircle(int poX, int poY, int r, unsigned int color);
void glcd_triangle( int poX1, int poY1, int poX2, int poY2, int poX3, int poY3,  unsigned int color);
void glcd_char(unsigned char ascii, unsigned int poX, unsigned int poY,unsigned int size, unsigned int fgcolor);
void glcd_string(char *argstring, unsigned int poX, unsigned int poY, unsigned int size,unsigned int fgcolor);
unsigned char glcd_number(unsigned char long_num,unsigned int poX, unsigned int poY,unsigned int size,unsigned int fgcolor);
unsigned char glcd_float(float floatNumber, unsigned int poX, unsigned int poY, unsigned int size, unsigned int fgcolor);
void glcd_pixel(unsigned int poX, unsigned int poY, unsigned int color);		//
void glcd_onePixel(unsigned short usX, unsigned short usY, unsigned long ulColor);	//
void glcd_setDisplayDirect(char Direction);
void glcd_orientation(unsigned char HV);


unsigned char DisplayDirect;
