#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <stdlib.h>	// abs()
#include <string.h>	// strlen()
#include "spi.c"
#include "font.c"
#include "glcd.h"
#include "komande.h"

#define FONT_SPACE 6
#define FONT_X 8
#define FONT_Y 8

void glcd_sendCmd(unsigned char data)
{
	glcd_dc_low();
	glcd_cs_low();
	SPI_MasterTransmit(data);
	glcd_cs_high();
}

void glcd_sendData(unsigned char data)
{
	glcd_dc_high();
	glcd_cs_low();
	SPI_MasterTransmit(data);
	glcd_cs_high();
}

void glcd_sendData16(unsigned int data)
{
	unsigned char data1 = data>>8;
	unsigned char data2 = data&0xff;
	glcd_dc_high();
	glcd_cs_low();
	SPI_MasterTransmit(data1);
	SPI_MasterTransmit(data2);
	glcd_cs_high();
}

void glcd_init (void)
{
	SPI_MasterInit();
	glcd_cs_high();
	glcd_dc_high();

	glcd_rst_on();
	_delay_ms(10);
	glcd_rst_off();

	glcd_sendCmd(ILI9341_CMD_POWER_ON_SEQ_CONTROL);
	glcd_sendData(ILI9341_CMD_IDLE_MODE_ON);
	glcd_sendData(ILI9341_CMD_MEMORY_WRITE);
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(ILI9341_CMD_TEARING_EFFECT_LINE_OFF);
	glcd_sendData(0x02); 	// XXX sto ovo radi?

	glcd_sendCmd(ILI9341_CMD_POWER_CONTROL_B);
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(ILI9341_CMD_POWER_CONTROL_2);
	glcd_sendData(ILI9341_CMD_PARTIAL_AREA);

	glcd_sendCmd(ILI9341_CMD_DRIVER_TIMING_CONTROL_A);
	glcd_sendData(0x85); 	// XXX sto ovo radi?
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(0x78); 	// XXX sto ovo radi?

	glcd_sendCmd(ILI9341_CMD_DRIVER_TIMING_CONTROL_B);
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(ILI9341_CMD_NOP);

	glcd_sendCmd(0xED);	// XXX sto ovo radi?
	glcd_sendData(0x64); 	// XXX
	glcd_sendData(0x03);	// XXX
	glcd_sendData(ILI9341_CMD_PARTIAL_MODE_ON);
	glcd_sendData(0X81); 	// XXX

	glcd_sendCmd(ILI9341_CMD_PUMP_RATIO_CONTROL);
	glcd_sendData(ILI9341_CMD_DISP_INVERSION_OFF);

	glcd_sendCmd(ILI9341_CMD_POWER_CONTROL_1);
	glcd_sendData(0x23);	//VRH[5:0] 	// XXX

	glcd_sendCmd(ILI9341_CMD_POWER_CONTROL_2);
	glcd_sendData(ILI9341_CMD_ENTER_SLEEP_MODE);

	glcd_sendCmd(ILI9341_CMD_VCOM_CONTROL_1);
	glcd_sendData(ILI9341_CMD_READ_MEMORY_CONTINUE);
	glcd_sendData(ILI9341_CMD_DISPLAY_OFF);

	glcd_sendCmd(ILI9341_CMD_VCOM_CONTROL_2);
	glcd_sendData(0x86);	//--	// XXX

	glcd_sendCmd(ILI9341_CMD_MEMORY_ACCESS_CONTROL);
	glcd_sendData(0x48);	//C8	//48 68gal.gal.gal.//28 E8 gal.gal.gal.	// XXX

	glcd_sendCmd(ILI9341_CMD_COLMOD_PIXEL_FORMAT_SET);
	glcd_sendData(ILI9341_CMD_WRITE_CONTENT_ADAPT_BRIGHTNESS);

	glcd_sendCmd(ILI9341_CMD_FRAME_RATE_CONTROL_NORMAL);
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(0x18); 	// XXX

	glcd_sendCmd(ILI9341_CMD_DISPLAY_FUNCTION_CONTROL);
	glcd_sendData(0x08); 	// XXX
	glcd_sendData(0x82);	// XXX
	glcd_sendData(0x27);	// XXX

	glcd_sendCmd(ILI9341_CMD_ENABLE_3_GAMMA_CONTROL);
	glcd_sendData(ILI9341_CMD_NOP);

	glcd_sendCmd(0x26);	//Gamma curve selected 	// XXX
	glcd_sendData(ILI9341_CMD_SOFTWARE_RESET);

	glcd_sendCmd(ILI9341_CMD_POSITIVE_GAMMA_CORRECTION);
	glcd_sendData(0x0F); 	// XXX
	glcd_sendData(0x31);	// XXX
	glcd_sendData(ILI9341_CMD_PAGE_ADDRESS_SET);
	glcd_sendData(ILI9341_CMD_READ_DISP_PIXEL_FORMAT);
	glcd_sendData(ILI9341_CMD_READ_DISP_SIGNAL_MODE);
	glcd_sendData(0x08); 	// XXX
	glcd_sendData(0x4E); 	// XXX
	glcd_sendData(0xF1); 	// XXX
	glcd_sendData(ILI9341_CMD_VERT_SCROLL_START_ADDRESS);
	glcd_sendData(0x07); 	// XXX
	glcd_sendData(ILI9341_CMD_ENTER_SLEEP_MODE);
	glcd_sendData(0x03);	// XXX
	glcd_sendData(ILI9341_CMD_READ_DISP_SIGNAL_MODE);
	glcd_sendData(ILI9341_CMD_READ_DISP_STATUS);
	glcd_sendData(ILI9341_CMD_NOP);

	glcd_sendCmd(ILI9341_CMD_NEGATIVE_GAMMA_CORRECTION);
	glcd_sendData(ILI9341_CMD_NOP);
	glcd_sendData(ILI9341_CMD_READ_DISP_SIGNAL_MODE);
	glcd_sendData(0x14); 	// XXX
	glcd_sendData(0x03);	// XXX
	glcd_sendData(ILI9341_CMD_SLEEP_OUT);
	glcd_sendData(0x07); 	// XXX
	glcd_sendData(0x31); 	// XXX
	glcd_sendData(ILI9341_CMD_POWER_CONTROL_2);
	glcd_sendData(0x48); 	// XXX
	glcd_sendData(0x08); 	// XXX
	glcd_sendData(0x0F); 	// XXX
	glcd_sendData(ILI9341_CMD_READ_DISP_PIXEL_FORMAT);
	glcd_sendData(0x31); 	// XXX
	glcd_sendData(ILI9341_CMD_MEMORY_ACCESS_CONTROL);
	glcd_sendData(ILI9341_CMD_READ_DISP_SELF_DIAGNOSTIC);

	glcd_sendCmd(ILI9341_CMD_SLEEP_OUT);
	_delay_ms(120); 

	glcd_sendCmd(ILI9341_CMD_DISPLAY_ON);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);
	glcd_fillScreen_void();
}

void glcd_setCol(unsigned int StartCol,unsigned int EndCol)
{
	glcd_sendCmd(ILI9341_CMD_COLUMN_ADDRESS_SET);
	glcd_sendData16(StartCol);
	glcd_sendData16(EndCol);
}

void glcd_setPage(unsigned int StartPage,unsigned int EndPage)
{
	glcd_sendCmd(ILI9341_CMD_PAGE_ADDRESS_SET);
	glcd_sendData16(StartPage);
	glcd_sendData16(EndPage);
}

void glcd_fillScreen(unsigned int XL, unsigned int XR, unsigned int YU, unsigned int YD,  unsigned int color)
{
	unsigned long XY=0;
	unsigned long i=0;

	if(XL > XR)
	{
		XL = XL^XR;
		XR = XL^XR;
		XL = XL^XR;
	}
	if(YU > YD)
	{
		YU = YU^YD;
		YD = YU^YD;
		YU = YU^YD;
	}
	XL = constrain(XL, MIN_X,MAX_X);
	XR = constrain(XR, MIN_X,MAX_X);
	YU = constrain(YU, MIN_Y,MAX_Y);
	YD = constrain(YD, MIN_Y,MAX_Y);

	XY = (XR-XL+1);
	XY = XY*(YD-YU+1);

	glcd_setCol(XL,XR);
	glcd_setPage(YU, YD);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);

	glcd_dc_high();
	glcd_cs_low();

	unsigned char Hcolor = color>>8;
	unsigned char Lcolor = color&0xff;
	for(i=0; i < XY; i++)
	{
		SPI_MasterTransmit(Hcolor);
		SPI_MasterTransmit(Lcolor);
	}

	glcd_cs_high();
}

void glcd_fillScreen_void()
{
	glcd_setCol(0, 239);
	glcd_setPage(0, 319);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);

	glcd_dc_high();
	glcd_cs_low();
	unsigned int i=0;
	for(i=0; i<38400; i++)
	{
		SPI_MasterTransmit(0);
		SPI_MasterTransmit(0);
		SPI_MasterTransmit(0);
		SPI_MasterTransmit(0);
	}
	glcd_cs_high();
}

void glcd_setXY(unsigned int poX, unsigned int poY)
{
	glcd_setCol(poX, poX);
	glcd_setPage(poY, poY);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);
}

void glcd_setPixel(unsigned int poX, unsigned int poY, unsigned int color)
{
	glcd_setXY(poX, poY);
	glcd_sendData16(color);
}

void glcd_fillRectangle(unsigned int poX, unsigned int poY, unsigned int length, unsigned int width, unsigned int color)
{
	glcd_fillScreen(poX, poX+length, poY, poY+width, color);
}

void glcd_hline( unsigned int poX, unsigned int poY, unsigned int length, unsigned int color)
{
	glcd_setCol(poX,poX + length);
	glcd_setPage(poY,poY);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);
	int i=0;
	for(i=0; i<length; i++)
		glcd_sendData16(color);
}


void glcd_vline( unsigned int poX, unsigned int poY, unsigned int length, unsigned int color)
{
	glcd_setCol(poX,poX);
	glcd_setPage(poY,poY+length);
	glcd_sendCmd(ILI9341_CMD_MEMORY_WRITE);
	int i=0;
	for(i=0; i<length; i++)
		glcd_sendData16(color);
}

void glcd_rectangle(unsigned int poX, unsigned int poY, unsigned int length, unsigned int width, unsigned int color)
{
	glcd_hline(poX, poY, length, color);
	glcd_hline(poX, poY+width, length, color);
	glcd_vline(poX, poY, width,color);
	glcd_vline(poX + length, poY, width,color);
}

void glcd_clr(unsigned int poX, unsigned int poY, unsigned int size)
{
	int i;
	for (i =0; i<FONT_X; i++ ) {
		unsigned char temp = pgm_read_byte(&simpleFont[96][i]);	// kocka
		unsigned char f=0;
		for(f=0;f<8;f++)
		{
			if((temp>>f)&0x01)
			{
				glcd_fillRectangle(poX+i*size, poY+f*size, size, size, BGCOLOR);
			}
		}
	}
}
