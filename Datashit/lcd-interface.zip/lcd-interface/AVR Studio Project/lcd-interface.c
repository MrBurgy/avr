// AVR ATMEGA32 - INTERNAL 4MHz CLK

// Include Files
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <util/delay.h>
#include "lcd.h"	//	THE LCD HEADER FILE TO INCLUDE

// For Bitvise Operation Simplification Defines
#define CLR(port,pin)	PORT ## port &= ~(1<<pin)
#define SET(port,pin)	PORT ## port |=  (1<<pin)
#define TOGL(port,pin)	PORT ## port ^=  (1<<pin)
#define READ(port,pin)	PIN  ## port &   (1<<pin)
#define OUT(port,pin)	DDR  ## port |=  (1<<pin)
#define IN(port,pin)	DDR  ## port &= ~(1<<pin)

int main(void){
// LCD
OUT(A,4); OUT(A,5); OUT(A,6);	// RS - RW - E
lcd_init(LCD_DISP_ON);
lcd_clrscr();
lcd_puts("Testing.. 1.2.3...");
}
