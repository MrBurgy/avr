
#include "english_6x8_pixel.h"
#include "write_chinese_string_pixel.h"

//
#define BIT(i)  (1<<i)  

#define SCLK_set   PORTA|=BIT(0)      //serial clock input
#define SCLK_clr   PORTA&=~BIT(0)  

#define SDIN_set  PORTA|=BIT(1)      //serial data input   
#define SDIN_clr  PORTA&=~BIT(1) 

#define LCD_DC_set   PORTA|=BIT(2)    //data/commande
#define LCD_DC_clr   PORTA&=~BIT(2)  

#define LCD_CE_set  PORTA|=BIT(3)      //chip enable
#define LCD_CE_clr  PORTA&=~BIT(3) 
 
#define LCD_RST_set  PORTA|=BIT(4)     //external reset input
#define LCD_RST_clr  PORTA&=~BIT(4) 


void delay_1us(void)                 //delay 1us
  {
     _delay_us(1);
  }

void delay_1ms(void)                 //delay 1ms
  {
    _delay_ms(1);
  }
  
void delay_nms(unsigned int n)       //delay nms
  {
   _delay_ms(n);
  }


void LCD_init(void)                 //LCD initialization
  {
    DDRA|=0X1F;    

     LCD_RST_clr;
    delay_1us();
     LCD_RST_set;
    
    LCD_CE_clr;

    delay_1us();
     LCD_CE_set;
  
    delay_1us();

    LCD_write_byte(0x21, 0);	// set LCD mode
    LCD_write_byte(0xc8, 0);	// set bias voltage
    LCD_write_byte(0x06, 0);	// temperature correction
    LCD_write_byte(0x13, 0);	// 1:48
    LCD_write_byte(0x20, 0);	// use bias command
    LCD_clear();	           // clear the LCD
    LCD_write_byte(0x0c, 0);	// set LCD mode,display normally
        
    LCD_CE_clr;    
  }


void LCD_clear(void)          // clear the LCD
  {
    unsigned int i;

    LCD_write_byte(0x0c, 0);			
    LCD_write_byte(0x80, 0);			

    for (i=0; i<504; i++)
	  {
       LCD_write_byte(0, 1);
	  }		
  }

/*-----------------------------------------------------------------------
LCD_set_XY              : Set the LCD coordinate functions

input parameter��X       ��0��83
               Y        ��0��5

created date           ��2013-4-25
-----------------------------------------------------------------------*/
void LCD_set_XY(unsigned char X, unsigned char Y)
  {
    LCD_write_byte(0x40 | Y, 0);		// column
    LCD_write_byte(0x80 | X, 0);          	// row
  }

/*-----------------------------------------------------------------------
LCD_write_char    : Display English characters

input parameter��c   :char to display

created date         ��2013-4-25
-----------------------------------------------------------------------*/
void LCD_write_char(unsigned char c)
  {
    unsigned char line;

    c -= 32;

    for (line=0; line<6; line++)
      LCD_write_byte(font6x8[c][line], 1);
  }

/*-----------------------------------------------------------------------
LCD_write_english_String  : Display English strings

input parameter��X       ��0��83
                Y        ��0��5

created date         ��2013-4-25	
-----------------------------------------------------------------------*/
void LCD_write_english_string(unsigned char X,unsigned char Y,char *s)
  {
    LCD_set_XY(X,Y);
    while (*s) 
      {
	 LCD_write_char(*s);
	 s++;
      }
  }
/*-----------------------------------------------------------------------
LCD_write_chinese_string: Display Chinese strings

	LCD_write_chi(0,0,12,7,0,0);
	LCD_write_chi(0,2,12,7,0,0);
	LCD_write_chi(0,4,12,7,0,0);	
-----------------------------------------------------------------------*/                        
void LCD_write_chinese_string(unsigned char X, unsigned char Y, 
                   unsigned char ch_with,unsigned char num,
                   unsigned char line,unsigned char row)
  {
    unsigned char i,n;
    
    LCD_set_XY(X,Y);                             //scale settings
    
    for (i=0;i<num;)
      {
      	for (n=0; n<ch_with*2; n++)              //write a chinese
      	  { 
      	    if (n==ch_with)                     
      	      {
      	        if (i==0) LCD_set_XY(X,Y+1);
      	        else
      	           LCD_set_XY((X+(ch_with+row)*i),Y+1);
              }
      	    LCD_write_byte(write_chinese[line+i][n],1);
      	  }
      	i++;
      	LCD_set_XY((X+(ch_with+row)*i),Y);
      }
  }
  


/*-----------------------------------------------------------------------
LCD_draw_map      : Bitmap drawing function

input parmenter��X��Y    ��starting point X,Y��
                 *map    ��bitmap data
                 Pix_x   ��highth
                 Pix_y   ��width

created date         ��2013-4-25
-----------------------------------------------------------------------*/
void LCD_draw_bmp_pixel(unsigned char X,unsigned char Y,unsigned char *map,
                  unsigned char Pix_x,unsigned char Pix_y)
  {
    unsigned int i,n;
    unsigned char row;
    
    if (Pix_y%8==0) row=Pix_y/8;      //calculate how many line is needed
      else
        row=Pix_y/8+1;
    
    for (n=0;n<row;n++)
      {
      	LCD_set_XY(X,Y);
        for(i=0; i<Pix_x; i++)
          {
            LCD_write_byte(map[i+n*Pix_x], 1);
          }
        Y++;                         //chang line
      }      
  }

/*-----------------------------------------------------------------------
LCD_write_byte    : write data to LCD

input parmenter��data    ��data
          command ��command

created date         ��2013-4-25
-----------------------------------------------------------------------*/
void LCD_write_byte(unsigned char dat, unsigned char command)
  {
    unsigned char i;
      LCD_CE_clr;
    
    if (command == 0)
       LCD_DC_clr;
    else
       LCD_DC_set;

		for(i=0;i<8;i++)
		{
			if(dat&0x80)
		     SDIN_set;
			else
		      SDIN_clr;
		    SCLK_clr;
			dat = dat << 1;
          	SCLK_set;
		}
       LCD_CE_set;
  }


