//Function: This procedure is used based on the AVR microcontroller ATMEGA32A-PU to control the Nokia5110LCD
//Editing environment: the AVR Studio 4.0
//Figure wiring according to the principle of
//fuse bytes:
//Low byte: 0xc1
//High byt: 0xd9
//Extend: 0x00
//Lock byte: 0xff
//Crystal: internal RC oscillator 8MHz
//Time: April 25, 2013
#include<avr/io.h>
#include <avr/delay.h>

#define uint unsigned int
#define uchar unsigned char

#include "nokia_5110.h"
#include "bmp_pixel.h"

/******************************************************************************/
void main(void) 
{
	LCD_init();       //LCD initialization
	LCD_clear();      //clear the LCD
	while(1)  
	{
		LCD_write_english_string(0,0," Welcome to  ");    //x=0,y=0    write from the start in the first row
		LCD_write_english_string(0,1," Amy  studio ");    //x=0,y=1    write from the start in the second row
		LCD_write_english_string(0,2,"amy-studio.com");
		LCD_write_english_string(0,3," Nokia5110 LCD");
		LCD_write_chinese_string(12,4,12,4,0,5);  

	}	  


}



