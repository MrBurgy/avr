/*
Isjecci koda za LCD.
U ovom slucaju preko intterupta pozivam ispisivanje na LCD

*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "lcd.h"
#include "lcd.c"
#include <avr/eeprom.h>
#include "uart.h"
#include "uart.c"

#define F_CPU 8000000UL 
#define UART_BAUD_RATE 9600      

volatile unsigned char trenutna; 
volatile int postavljena;
volatile int postavljenaROM;
volatile int grijac;
unsigned int brojac;
unsigned int global_sread;
unsigned int polje[3];
unsigned int postavljenaUART=0;
int i;
char c;
int uvjet=0;

void ispisi_temp() {
	char buffer[7];
	trenutna=ADCH;

	lcd_clrscr();
	lcd_puts_P("Trenutna t: ");
	itoa(trenutna,buffer,10);
	lcd_puts(buffer);
	lcd_puts_P(" C");

	lcd_gotoxy(0,1);
	lcd_puts_P("Grij do: ");
	itoa(postavljena,buffer,10);
	lcd_puts(buffer);
	lcd_puts_P(" C");
}

ISR(ADC_vect)
{
	if(bit_is_clear(PINB,1))	// gore tipka
	{
		postavljena++;
		ispisi_temp();
	}
	if(bit_is_clear(PINB,5))	// dolje tipka
	{
		postavljena--;
		ispisi_temp();
	}
	else
		ispisi_temp();
}


int main (void)
{
	char buffer[7];

	adc_init();
	_delay_ms(200);
	lcd_init(LCD_DISP_ON);

	uc_init();
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );
	sei();	// UART is interrupt driven

	while(1){
		ADCSRA|=(1<<ADSC); // ADC start
		_delay_ms(500);
		
		//ispisi_temp();

		// grij sve dok je trenutna manja od postavljene
		if(trenutna < postavljena)
			pali_grijac();
		else
			gasi_grijac();

		serial_salji();
		serial_primi();

		if(polje[0]!=0 && polje[1]!=0)
		{
			postavljena = postavljenaUART;
		}
	}
	return(0);
}
