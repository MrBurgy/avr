/********************************************************************

Example program to learn the interfacing of Ultra Sonic Range Finder 
Module with AVR ATmega8 Microcontroller.

Ultra Sonic Module Type: 4 PIN
Interface: Trigger input pulse, echo output pulse.

Connection

Sensor | MCU
_____________
Trig   | PC0
Echo   | PC1
 
                                     NOTICE
									--------
NO PART OF THIS WORK CAN BE COPIED, DISTRIBUTED OR PUBLISHED WITHOUT A
WRITTEN PERMISSION FROM EXTREME ELECTRONICS INDIA. THE LIBRARY, NOR ANY PART
OF IT CAN BE USED IN COMMERCIAL APPLICATIONS. IT IS INTENDED TO BE USED FOR
HOBBY, LEARNING AND EDUCATIONAL PURPOSE ONLY. IF YOU WANT TO USE THEM IN 
COMMERCIAL APPLICATION PLEASE WRITE TO THE AUTHOR.


WRITTEN BY:
AVINASH GUPTA
me@avinashgupta.com
********************************************************************/

#include <avr/io.h>
#include <util/delay.h>

#include "lib/lcd/lcd.h"

/********************************************************************

Configuration Area.
UltraSonic (US) sensor connection.

in this example it is connected to as follows

Sensor | MCU
_____________
Trig   | PC0
Echo   | PC1

********************************************************************/

#define US_PORT PORTC
#define	US_PIN	PINC
#define US_DDR 	DDRC

#define US_TRIG_POS	PC0
#define US_ECHO_POS	PC1


/********************************************************************

This function measures the width of high pulse in micro second.

********************************************************************/

#define US_ERROR		-1
#define	US_NO_OBSTACLE	-2

void HCSR04Init();
void HCSR04Trigger();

void HCSR04Init()
{
	US_DDR|=(1<<US_TRIG_POS);
}

void HCSR04Trigger()
{
	//Send a 10uS pulse on trigger line
	
	US_PORT|=(1<<US_TRIG_POS);	//high
	
	_delay_us(15);				//wait 15uS
	
	US_PORT&=~(1<<US_TRIG_POS);	//low
}

uint16_t GetPulseWidth()
{
	uint32_t i,result;

	//Wait for the rising edge
	for(i=0;i<600000;i++)
	{
		if(!(US_PIN & (1<<US_ECHO_POS))) 
			continue;	//Line is still low, so wait
		else 
			break;		//High edge detected, so break.
	}

	if(i==600000)
		return US_ERROR;	//Indicates time out
	
	//High Edge Found

	//Setup Timer1
	TCCR1A=0X00;
	TCCR1B=(1<<CS11);	//Prescaler = Fcpu/8
	TCNT1=0x00;			//Init counter

	//Now wait for the falling edge
	for(i=0;i<600000;i++)
	{
		if(US_PIN & (1<<US_ECHO_POS))
		{
			if(TCNT1 > 60000) break; else continue;
		}
		else
			break;
	}

	if(i==600000)
		return US_NO_OBSTACLE;	//Indicates time out

	//Falling edge found

	result=TCNT1;

	//Stop Timer
	TCCR1B=0x00;

	if(result > 60000)
		return US_NO_OBSTACLE;	//No obstacle
	else
		return (result>>1);
}
void main()
{
	uint16_t r;
	
	_delay_ms(100);	//Let the LCD Module start

	//Initialize the LCD Module
	LCDInit(LS_NONE);
	
	//Set io port direction of sensor
	HCSR04Init();

	LCDClear();
	LCDWriteString("Ultra Sonic");
	LCDWriteStringXY(0,1,"Sensor Test");

	_delay_ms(2500);
	
	LCDClear();


	while(1)
	{
		
		//Send a trigger pulse
		HCSR04Trigger();

		//Measure the width of pulse
		r=GetPulseWidth();

		//Handle Errors
		if(r==US_ERROR)
		{
			LCDWriteStringXY(0,0,"Error !");
		}
		else if(r==US_NO_OBSTACLE)
		{
			LCDWriteStringXY(0,0,"Clear !");
		}
		else
		{
		
			int d;

			d=(r/58.0);	//Convert to cm

			LCDWriteIntXY(0,0,d,4);
			LCDWriteString(" cm");

			_delay_ms(500);
		}
	}

}
