#include <avr/io.h>
#include <util/delay.h>

#define STEPPER_DDR1	DDRB
#define STEPPER_PORT1	PORTB
#define STEP1		0	// PB0
#define STEPPER_DDR2	DDRB
#define STEPPER_PORT2	PORTB
#define STEP2		6	// PB6
#define STEPPER_DDR3	DDRB
#define STEPPER_PORT3	PORTB
#define STEP3		2	// PB2
#define STEPPER_DDR4	DDRB
#define STEPPER_PORT4	PORTB
#define STEP4		7	// PB7

#define	STEPPER_DELAY	1
#define	N_of_steps		64
#define	gear_reduction		8

void stepper_init()
{
	STEPPER_DDR1 |= (1<<STEP1);
	STEPPER_PORT1 &=~(1<<STEP1);
	STEPPER_DDR2 |= (1<<STEP2);
	STEPPER_PORT2 &=~(1<<STEP2);
	STEPPER_DDR3 |= (1<<STEP3);
	STEPPER_PORT3 &=~(1<<STEP3);
	STEPPER_DDR4 |= (1<<STEP4);
	STEPPER_PORT4 &=~(1<<STEP4);
}

void stepperCW(float Num_of_rot)
{
	for(float i=0;i<N_of_steps*gear_reduction*Num_of_rot;i++)
	{
		STEPPER_PORT1 |= 1<<STEP1;	//1
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT2 |= 1<<STEP2;	//12
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 &=~(1<<STEP1);	//2
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT3 |= 1<<STEP3;	//23
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT2 &=~(1<<STEP2);	//3
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT4 |= 1<<STEP4;	//34
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT3 &=~ (1<<STEP3);	//4
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 |= 1<<STEP1;	//41
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT4 &=~(1<<STEP4);	//1
	}
	stepper_init();
	_delay_ms(5);
}

void stepperCCW(float Num_of_rot)
{
	for(float i=0;i<N_of_steps*gear_reduction*Num_of_rot;i++)
	{
		STEPPER_PORT1 |=1<<STEP4;	//4
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 |=1<<STEP3;	//43
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 &=~ (1<<STEP4);	//3
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 |=1<<STEP2;	//32
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 &=~(1<<STEP3);	//2
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 |=1<<STEP1;	//21
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 &=~ (1<<STEP2);	//1
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 |=1<<STEP4;	//14
		_delay_ms(STEPPER_DELAY);
		STEPPER_PORT1 &=~ (1<<STEP1);	//4
	}
	stepper_init();
	_delay_ms(5);
}
