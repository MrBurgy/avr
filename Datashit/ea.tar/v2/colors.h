#define black	0x0000	// 
#define white	0xFFFF	// RGB
#define red	0xF800	// R
#define green	0x07E0	// G
#define blue	0x001F	// B
#define yellow	0xFFE0  // RG
#define cyan	0x07FF	// GB
#define magenta	0xF81F	// RB
#define gray	0x0821	// 00001 000001 00001
