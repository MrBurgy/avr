#define F_CPU 8000000UL
#define UART_BAUD_RATE	9600      
#define __AVR_ATmega328P__
//#include "glcd.c"
#include "stepper.c"
#include "adc.c"
#include "ambient_light.c"
#include "motion_sensor.c"
#include <stdlib.h> 	// itoa()
#include "uart.h"
#include "uart.c"

void jeremija(int temp, int foto1, int foto2, int mousn_senzor, int stepper, int ambient_light_var, int grijac)
{
	//jeremija salje log na serijski
	// format temp:foto1:foto2:mousn_senzor:stepper:ambient_light:grijac

	char buffer[7];

	itoa(temp,buffer,10);
	uart_puts(buffer);
	uart_putc(':');

	itoa(foto1,buffer,10);
	uart_puts(buffer);
	uart_putc(':');

	itoa(foto2,buffer,10);
	uart_puts(buffer);
	uart_putc(':');

	itoa(mousn_senzor,buffer,10);
	uart_puts(buffer);
	uart_putc(':');

	// float to char
	//snprintf(buffer, sizeof(buffer), "%.2f", ambient_light);
	itoa(ambient_light_var,buffer,10);
	uart_puts(buffer);
	uart_putc(':');

	itoa(grijac,buffer,10);
	uart_puts(buffer);

	// x oznacava kraj linije
	uart_putc(':');
	uart_putc('x');
	uart_putc('\n');
	uart_putc('\r');
}


void glcd_ispisi(int temp, int foto1, int foto2, int mousn_senzor, int stepper, double ambient_light, int grijac)
{
	/*
		// delete before printing
		glcd_fillRectangle(150,0,60,20,bgcolor);
		glcd_fillRectangle(100,20,60,20,bgcolor);
		glcd_fillRectangle(100,40,60,20,bgcolor);

		glcd_string("Temperatura: ",0,0,2,white);
		glcd_number(2*adc_read(0),150,0,2,red);

		glcd_string("Foto1: ",0,20,2,white);
		glcd_number(adc_read(1),100,20,2,red);

		glcd_string("Foto2: ",0,40,2,white);
		glcd_number(adc_read(2),100,40,2,red);
		//_delay_ms(100);

		glcd_string("Clock: ",10,140,2,white);
		glcd_number(clock_h,45,160,2,yellow);
		glcd_char(':',70,160,2,red);
		if(clock_m < 10)
		{
			glcd_number(clock_m,92,160,2,yellow);
			glcd_number(0,80,160,2,yellow);
		}
		else if (clock_m >= 10)
			glcd_number(clock_m,80,160,2,yellow);

		glcd_string("Alarm: ",10,200,2,white);
		glcd_number(alarm_h,50,220,2,yellow);
		glcd_char(':',70,220,2,red);
		if(alarm_m < 10)
		{
			glcd_number(0,80,220,2,yellow);
			glcd_number(alarm_m,92,220,2,yellow);
		}
		else if (alarm_m >= 10)
				//stepperCCW(1);
		ambient_light(0);

		int mousn=5;
		mousn = motion_get();
		glcd_clrLine(300,2);
		glcd_number(mousn,50,300,2,green);

	glcd_number(alarm_m,92,220,2,yellow);
	*/
}

int main()
{
	//glcd_init();
	//glcd_led_on();
	stepper_init();
	adc_init();
	ambient_light_init();
	//usart_init_ie(51);	// 9600
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );  
	sei();


	/*
	int clock_h = 19;
	int clock_m = 2;
	int alarm_h = 8;
	int alarm_m = 5;
	*/

	int temp;
	int foto1;
	int foto2;
	int mousn_senzor;
	int stepper;
	int ambient_light_var;
	int grijac;

	ambient_light(50);

		char c;
	while(1)
	{
		temp = adc_read(0);
		foto1 = adc_read(1);
		foto2 = adc_read(2);
		mousn_senzor = motion_get();
		ambient_light_var = ambient_light_status();

		stepperCW(0.1);

		jeremija(temp, foto1, foto2, mousn_senzor, stepper, ambient_light_var, grijac);
		//glcd_ispisi(temp, foto1, foto2, mousn_senzor, stepper, ambient_light, grijac);

		c = uart_getc();
		//if( (c <= 127) && (c>=32))
		if(c != '\0')
		{
			uart_puts("serijski je primio: ");
			uart_putc(c);
			uart_puts("\r\n");
		}

	}
	return 0;
}
