#define MOTION_SENSOR_DDR	DDRD
#define MOTION_SENSOR_PORT	PORTD
#define MOTION_SENSOR		2	// PD2

void motion_init()
{
	MOTION_SENSOR_DDR &= ~(1<<MOTION_SENSOR);
}

int motion_get()
{
	if bit_is_clear(PIND,2)	// XXX doradit preko varijable
		return 0;
	else
		return 1;
}

// XXX dodat timer
// ako je proslo manje od 60 sekundi nakon paljenja sensor jednak 0
// dat mu vremena da mu se lampe ugriju
