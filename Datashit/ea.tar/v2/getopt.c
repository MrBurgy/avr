#include <stdio.h>
#include <getopt.h>

void print_help();

int main(int argc, char *argv[]) {
	int opt;

	if(argc == 1) // no arguments given
	{
		fprintf(stderr, "This program needs arguments.\n\n");
		print_help();
	}

	while((opt = getopt(argc, argv, "abc?")) != -1)
	{
		switch(opt)
		{
			case 'a':
				printf("odabrano a.\n");
				break;
			case 'b':
				printf("odabrano b.\n");
				break;
			case 'c':
				printf("odabrano c.\n");
				break;
				/*
			case ':':
				//fprintf(stderr, "%s: Error - Option `%c' needs a value\n\n", PACKAGE, optopt);
				printf("odabrano :.\n");
				break;
				*/
			case '?':
				//fprintf(stderr, "%s: Error - No such option: `%c'\n\n", PACKAGE, optopt);
				// zadnji, pozove se u slucaju krivog arguemnta
				print_help();
				break;
		}
	}

	// print all remaining options
	// u tutorialima ima, je li doista potrebno?
	/*
	for(; optind < argc; optind++)
		printf("argument: %s\n", argv[optind]);
	*/

	return 0;
}

void print_help() {
	printf("Help is here.\n");
}
