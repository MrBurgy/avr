#!/bin/sh
LOG = /tmp/lazy_room.log
DEV = /dev/ttyUSB0	# XXX na Linuxu je drugacije
PROGRAM = /dev/cu	# XXX na Linuxu je drugacije
PID = `ps aux | grep $PROGRAM | grep -v grep | awk '{PRINT $2}' | head -n 1 `

FOTO1 = `awk '{PRINT $1}' $LOG | tail -n 1 `


if ["$1" = exit]; then
	kill $PID
	echo exit
elif ["$1" = foto1]; then
	printf "%b\n" $FOTO1







elif ['$1' = help]; then
	echo koristenje:
	echo ./lazy_room.sh
	echo foto1
	echo foto2
	echo ...
	echo exit
else
	echo koristenje:
	echo ./lazy_room.sh
	echo foto1
	echo foto2
	echo ...
	echo exit
fi
