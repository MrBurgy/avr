void adc_init()
{
	// XXX nepotreban init?
	ADMUX  |= (1<<REFS0) | (1<<ADLAR);
	ADCSRA |= (1<<ADEN);
	ADCSRA |= (1<<ADPS2) | (1<<ADPS1);
}

int adc_read(int ch)
{
	int adc_var;	// zbog magije

	// init
	ADMUX  |= (1<<REFS0) | (1<<ADLAR);
	ADCSRA |= (1<<ADEN);
	ADCSRA |= (1<<ADPS2) | (1<<ADPS1);

	ADMUX   = ch;
	ADMUX  |= (1<<REFS0) | (1<<ADLAR);	// init dio
	ADCSRA |= (1<<ADSC);

        while(ADCSRA & (1 << ADSC));      // wait for the ADC to finish 
	adc_var = ADCH;	// treba procitat ADCH da moze ponovo
	return adc_var;
}
