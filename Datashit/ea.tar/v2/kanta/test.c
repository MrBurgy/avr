#include <stdio.h>

int main()
{
	char buffer[7];
	float ambient_light=0.8;

	snprintf(buffer, sizeof(buffer), "%f", ambient_light);

	printf("ambijentno svetlo: %s", buffer);

	return 0;
}
