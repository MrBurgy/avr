#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

//defines needed for Atmega328:
#define    UCSRA    UCSR0A
#define    UCSRB    UCSR0B
#define    UCSRC    UCSR0C
#define    UBRRH    UBRR0H
#define    UBRRL    UBRR0L
#define    UDRE    UDRE0
#define    UDR    UDR0
#define    RXC    RXC0
#define    RXEN    RXEN0
#define    TXEN    TXEN0
#define    UCSZ1    UCSZ01
#define    UCSZ0    UCSZ00
#define output_high(port,pin) port |= (1<<pin)
#define output_low(port,pin) port &= ~(1<<pin)
#define set_output(portdir,pin) portdir |= (1<<pin)

#ifndef F_CPU
   #define F_CPU 8000000UL     
#endif

#define   USART0_BAUD 9600         //Baud rate USART_0 

/* Initialize UART */
//void InitUART (unsigned char baudrate){
  /*[> Set the baud rate <]*/
  /*UBRRL = baudrate;*/
  /*[> Enable UART receiver and transmitter <]*/
  /*UCSRB = (1 << RXEN) | (1 << TXEN);*/
  /*[> set to 8 data bits, 1 stop bit <]*/
  /*UCSRC = (1 << UCSZ1) | (1 << UCSZ0);*/
 void usart0_init(void) 
{
UBRR0L = (uint8_t) (F_CPU / (16UL * USART0_BAUD)) - 1;
   UBRR0H = (uint8_t) ((F_CPU / (16UL * USART0_BAUD)) - 1) >>8;
   UCSR0B = (1<<TXEN0 | 1<<RXEN0);    // tx/rx enable 
}

/* Read and write functions */
unsigned char ReceiveByte (void){
  /* Wait for incomming data */
  while (!(UCSRA & (1 << RXC)));
  /* Return the data */
  return UDR;
}

void TransmitByte (unsigned char data){
  /* Wait for empty transmit buffer */
  while (!(UCSRA & (1 << UDRE)));
  /* Start transmition */
  UDR = data;
}

int serijski(void) {
   unsigned char gotByte;
//For Atmega328, the clock speed is 16?
//Therefore, UBRR=16000000/(16x9600)-1=103d
   //InitUART(103); //set baudrate to 9600 bps
	usart0_init();

	TransmitByte('a');
   gotByte=ReceiveByte();   //receive the byte
   TransmitByte(gotByte);   //echo back
 } 
