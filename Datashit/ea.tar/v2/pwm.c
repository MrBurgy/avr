void pwm_init()
{
	int CompareValue = 15000;
	DDRB |= (1<<PINB1);					//pin na kojemu je OCR1A mora bit setan na output
	//PORTB |= (1<<PINB1);
	//PORTB &= ~(1<<PINB1);

	TCCR1A |= (1<<WGM11) | (1<<COM1A1) | (1<<COM1A0);	//setings
	TCCR1B |= (1<<WGM13) | (1<<WGM12) | (1<<CS10);		//-//-
	ICR1 = CompareValue;					//sadr�i compare vrijednost
	OCR1A = ICR1;
}

void pwm_duty(int value)
{
	OCR1A = ICR1 - value;
}
