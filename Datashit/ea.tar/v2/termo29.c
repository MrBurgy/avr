// ADC 10 bita = 1024 razine
// 0-5V
// LM35 5mV = 1 stupanj

// termo23.c - sredit da se na ekranu fino slazu ADC i tipke
// dodan i EPROM

// XXX
// nakon reprogramiranja postavljenaROM = 255
// nakon power reseta radi oke

// termo24.c
// serial

// termo25.c
// serial read

// termo26.c
// serial read

// termo27.c
// temperaturu za serijskog stavi kao zadanu

// termo28.c
// sredi int temperaturu zadanu sa serijskog

// termo29.c
// ispituj temperaturu za serijskog

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "lcd.h"
#include "lcd.c"
#include <avr/eeprom.h>
#include "uart.h"
#include "uart.c"

#define F_CPU 8000000UL 
#define UART_BAUD_RATE 9600      

volatile unsigned char trenutna; 
volatile int postavljena;
volatile int postavljenaROM;
volatile int grijac;
unsigned int brojac;
unsigned int global_sread;
unsigned int polje[3];
unsigned int postavljenaUART=0;
int i;
char c;
int uvjet=0;

void adc_init(void) 
{
	ADMUX=(1<<REFS1)|(1<<REFS0)|(1<<ADLAR)|(0<<MUX3)|(0<<MUX2)|(0<<MUX1)|(0<<MUX0);//ADC0
	ADCSRA=(1<<ADEN)|(0<<ADFR)|(1<<ADIE) |(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
	sei();
}

void uc_init() {
	DDRB  &=~(1<<1)|(1<<5);  // PB 1 5 su tipke
	PORTB |=~(1<<1)|(1<<5);  // pullup R za tipke
	DDRB |= _BV(DDB3);	// LED je PB3
	PORTB &= ~_BV(PB3);	// ugasi LED
}

void ispisi_temp() {
	char buffer[7];
	trenutna=ADCH;

	lcd_clrscr();
	lcd_puts_P("Trenutna t: ");
	itoa(trenutna,buffer,10);
	lcd_puts(buffer);
	lcd_puts_P(" C");

	lcd_gotoxy(0,1);
	lcd_puts_P("Grij do: ");
	itoa(postavljena,buffer,10);
	lcd_puts(buffer);
	lcd_puts_P(" C");
}

ISR(ADC_vect)
{
	if(bit_is_clear(PINB,1))	// gore tipka
	{
		postavljena++;
		ispisi_temp();
	}
	if(bit_is_clear(PINB,5))	// dolje tipka
	{
		postavljena--;
		ispisi_temp();
	}
	else
		ispisi_temp();
}

pali_grijac()
{
	PORTB |= _BV(PB3);	// upali LED
	PORTB |= _BV(PB6);	// upali TRIAC
	grijac = 1;
}

gasi_grijac()
{
	PORTB &= ~_BV(PB3);     // ugasi LED
	PORTB &= ~_BV(PB6);	// ugasi TRIAC
	grijac = 0;
}

void EEPROM_write(unsigned int uiAddress, unsigned char ucData)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE));
	/* Set up address and data registers */
	EEAR = uiAddress;
	EEDR = ucData;
	/* Write logical one to EEMWE */
	EECR |= (1<<EEMWE);
	/* Start eeprom write by setting EEWE */
	EECR |= (1<<EEWE);
}

unsigned char EEPROM_read(unsigned int uiAddress)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE));
	/* Set up address register */
	EEAR = uiAddress;
	/* Start eeprom read by writing EERE */
	EECR |= (1<<EERE);
	/* Return data from data register */
	return EEDR;
}

void serial_salji() {
	char buffer[7];

	itoa(brojac, buffer, 10);
	uart_puts(buffer);
	uart_puts_P(" ");
	brojac++;

	trenutna=ADCH;
	itoa(trenutna, buffer, 10);
	uart_puts(buffer);
	uart_puts_P(" ");

	itoa(postavljena, buffer, 10);
	uart_puts(buffer);
	uart_puts_P(" ");

	itoa(grijac, buffer, 10);
	uart_puts(buffer);
	uart_puts_P(" ");

	// temperatura postavljena preko serijskog, int
	/*
	if(polje[0]!=0 && polje[1]!=0) {
		itoa(postavljenaUART,buffer,10);
		uart_puts(buffer);
	}
	else {
		uart_puts_P("0");
		postavljenaUART = 0;
	}
	*/

	_delay_ms(8000);	// 1s
	uart_puts_P("\r\n");
}

void serial_primi() {
	char c;
	char buffer[7];

	if (c & UART_NO_DATA)
	{
		// no data available from UART 
		//uvjet = 0;
	}
	else
	{
		// new data available from UART
		if (c & UART_FRAME_ERROR)
			uart_puts_P("UART Frame Error: ");
		if (c & UART_OVERRUN_ERROR)
			uart_puts_P("UART Overrun Error: ");
		if (c & UART_BUFFER_OVERFLOW)
			uart_puts_P("Buffer overflow error: ");

		// primi i zapisi u polje
		c = uart_getc();
		polje[0] = c;
		c = uart_getc();
		polje[1] = c;
		c = uart_getc();
		polje[2] = c;

		// pretvori char polje u int var
		if(polje[0]!=0 && polje[1]!=0)
		{
			postavljenaUART = (int)((polje[0]-48)*10+(polje[1]-48));
		}
		//uvjet = 1;
	}
}

int main (void)
{
	char buffer[7];

	adc_init();
	_delay_ms(200);
	lcd_init(LCD_DISP_ON);

	uc_init();
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );
	sei();	// UART is interrupt driven

	/*
	// Telemetrijski sustav regulacije temperature
	lcd_puts_P(" Telemetrijski\n");
	lcd_puts_P("     sustav");
	_delay_ms(2000);
	lcd_clrscr();
	lcd_puts_P("  regulacije\n");
	lcd_puts_P("  temperature");
	_delay_ms(2000);
	lcd_clrscr();
	*/

	// na pocetku ucitaj postavljenu iz ROMa
	// XXX sa ovim otkomentiranim ne moze se postavit preko serijskog
	//postavljena = EEPROM_read(0x10);
	//postavljena = 20;

	while(1){
		ADCSRA|=(1<<ADSC); // ADC start
		_delay_ms(500);
		
		//ispisi_temp();

		// grij sve dok je trenutna manja od postavljene
		if(trenutna < postavljena)
			pali_grijac();
		else
			gasi_grijac();

		// provjeri jel postavljena temperatura jednaka onoj u ROMu
		// ako nije spremi postavljenu u ROM
		// XXX nakon reprogramiranja postavljena = 255
		/*
		postavljenaROM = EEPROM_read(0x10);
		if (postavljena != postavljenaROM)
			EEPROM_write(0x10,postavljena);
		postavljenaROM = EEPROM_read(0x10);
		*/
		// XXX kad se isteka serijski modul postavljena krene divljat
		// XXX magicno vise ne zeli primit temperaturu preko serijskog

		serial_salji();
		serial_primi();

		if(polje[0]!=0 && polje[1]!=0)
		{
			postavljena = postavljenaUART;
		}
	}
	return(0);
}
