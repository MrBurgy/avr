#include "pwm.c"

#define AMBIENT_LIGHT_DDR	DDRB
#define AMBIENT_LIGHT_PORT	PORTB
#define AMBIENT_LIGHT	1	// PB1

int ambient_light_percent;

void ambient_light_init()
{
	pwm_init();
	AMBIENT_LIGHT_DDR |= (1<<AMBIENT_LIGHT);
}

void ambient_light(int percent)
{
	ambient_light_percent = percent;
	if (percent >= 0 && percent <= 100)
	{
		float tmp = 0;
		int tmp2 = 0;
		tmp = 15000*percent/100;
		tmp2 = (int) tmp;
		
		pwm_duty(tmp2);
		//glcd_number(tmp2,100,100,2,cyan);
	}
	else
	{
		// zajeb
		//glcd_string("error in setting ambient light, te iss rodjak.",0,0,2,red);
	}
}

int ambient_light_status()
{
	return ambient_light_percent;
}
